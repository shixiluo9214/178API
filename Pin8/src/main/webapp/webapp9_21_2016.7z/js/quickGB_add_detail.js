(function($){
	$(document).ready(function() {
		var vm = new Vue({
			el: "body",
			data: {
				addName: "",
				addMark: "",
				addPrice: "",
				addQuantity: "",
				addImage:""
			},
			methods: {
				confirmAdd: function(){
					var obj = {
						name: this.addName,
						mark: this.addMark,
						price: this.addPrice,
						quantity: this.addQuantity,
						img: this.addImage
					};
					sessionData("addDetail",obj);
					location.href = "./quickGB_add.html";
				},
				addOneImage: function(){
					$("#imgFile").click();
				}
			}
		});

		$("#imgFile").on("change",function(){
			vm.addImage = $(this).val();
		});
	});	
})(jQuery);
