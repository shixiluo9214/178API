(function($){
	$(document).ready(function() {
		Vue.transition("popupTransition",{
			enterClass: "fadeInUp",
			leaveClass: "fadeOutDown"
		})
		var vm = new Vue({
			el: "body",
			data: {
				showPopup: false,
				catalogInfo: '',
				addressInfo: '',
				scrollInfo: '',

				title: '',
				description: '',
				category: '',
				time: '',
				rule: '',
				count: '',
				position: '',
				checkStatus: false
			},
			computed: {
				nextAvail: function(){
					return (this.title && this.description && this.category && this.count && this.time && this.rule && this.position);
				}
			},
			methods: {
				toShowCategory: function(){
					this.showPopup = true;
					this.scrollInfo = this.catalogInfo.items;
					vm.$once("updateSelected", function(value){
						this.category = value;
					});
				},
				toShowTime: function(){
					$("#deadline").focus();
				},
				toShowRule: function(){
					this.showPopup = true;
					this.scrollInfo = [{'name':'按商品数量分配'},{'name':'参与者均分'},{'name':'免运费'}];
					vm.$once("updateSelected", function(value){
						this.rule = value;
					});
				},
				toShowPosition: function(){
					this.showPopup = true;
					this.scrollInfo = this.addressInfo;
					vm.$once("updateSelected", function(value){
						this.position = value;
					});
				},

				selectPopup: function(value){
					this.showPopup = false;
					vm.$emit("updateSelected", value);
				},
				nextStep: function(){
					var obj = {
						title: this.title,
						description: this.description,
						category: this.category,
						time: this.time,
						rule: this.rule,
						count: this.count,
						position: this.position,
						checkStatus: this.checkStatus
					};
					sessionData("addInfo",obj);
					location.href = "quickGB_add.html";
				},
				getConfig: function(){
					var self = this;
					$.ajax({
						type: 'POST',
						url: '../comm/getConfig',
						data: JSON.stringify({
							//to do
							"configType": "groupbuy_catalog"
						}),
						dataType: 'json',
						contentType: 'application/json',
						success: function(result){
							if(result.status==0){
								self.catalogInfo = result.bean[0];
							}
							console.log("catalog success");
							self.$log("catalogInfo");
						},
						error: function(result){
						  	console.log('error',result);
						}
					});
				},
				getAddress: function(){
					var self = this;
					$.ajax({
						type: 'POST',
						url: '../user/getAddresses',
						data: JSON.stringify({
							//to do
							"userId": "76"
						}),
						dataType: 'json',
						contentType: 'application/json',
						success: function(result){
							if(result.status==0){
								self.addressInfo = result.bean;
							}
							console.log("address success");
							self.$log("addressInfo");
						},
						error: function(result){
						  	console.log('error',result);
						}
					});
				}
			},
			ready: function(){
				localStorage.clear();
				this.getConfig();
				this.getAddress();
			},
		});
	});	
})(jQuery);
